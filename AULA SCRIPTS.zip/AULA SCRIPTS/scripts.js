//scripts.js
// variaveis (fracamente tipado)
//int, float, boolean, string, char, object, function
var a = 10;
var b = 20;
var c = a + b; // operação matemática

var nome = "Ana";
var sobrenome = "Mendes";
var nomeCompleto = nome +" "+ sobrenome; // Concatenação

console.log(nomeCompleto);

//operadores lógicos 
//&& (E), || (OU), ! (NOT)

//operadores condicionaris
//==, >, >=, <, <=, !=

//estruturas condicionais
var idade = 15

	if (idade >= 18) {
	console.log("Maior de idade");
}
	else if (idade <11) {
	console.log("Criança");
}
 	else{
	console.log('Menor de idade');
}

var civil = "C";
switch(civil){
	case "C":
		console.log("Casado");
		break;
	case "U":
		console.log("União estável");
		break;
	default:
		console.log("Solteiro");
		break;
}

//estruturas de repetição
var n = 1;
console.log("WHILE");
while (n <= 10){
	console.log( n );
	n++;
}

console.log("FOR");
for (var i =1; i<=10; i++){
	console.log(i);
}

//Vetores, Matrizes e Objetos
var cidades = new Array("Ituiutaba", "Capinópolis");
cidades[2] = "Santa Vitória";
cidades[cidades.length]= "Gurinhatã";
cidades[cidades.length]= "Canápolis";

console.log(cidades);

//Exibir todas as cidades em um FOR
for(var i=0; i< cidades.length; i++){
	console.log(cidades[i]);
}
console.log("--------------------------------");

//{} DEFINE OBJETO

var ficha = {
	//campo:valor,
	nome:"Bruno",
	idade:29,
	doador:true,
	altura:1.78
};

console.log(ficha);//mostra tudo
console.log(ficha["nome"]);//nome sintaxe de vetor
console.log(ficha.nome);//nome sintaxe de objeto

//for each(para cada), nao se prende a numeros e sim a indivíduos
console.log("FOR EACH");
for(var campo in ficha){
	console.log(campo + ": "+ ficha[campo]);
}

console.log("--------------------------------");

var pizza={
	sabor: "4 queijos",
	ingredientes: ["Mussarela", "Chedar", "Parmesão", "Catupiry"],
	tamanhos:{
		p: 19.90,
		m: 29.90,
		g: 39.90
	}

};

console.log( pizza.tamanhos.m );

console.log("---VETORES E OBJETOS---");
//Vetores de objetos
var turma = new Array();

var aluno1={
	nome: "Adriano",
	matricula: 123,
	aprovado: true
};

var aluno2 = {
	nome: "Bruna",
	matricula: 456,
	aprovado: true
};

var aluno3 = {
	nome: "Cláudia", 
	matricula: 789,
	aprovado: false
};

//Métodos de estruturas de dados
//push(elemento) ->insere no final
//pop -> remove do final
//shift(elemento) -> insere no início
//unshift -> remove do início


turma.push(aluno1);
turma.push(aluno2);
turma.push(aluno3);

console.log(turma[2].nome);

console.log("--------------------------------");
//imprima todos os nomes dos alunos matriculados na turma (percorrendo o vetor)

for( var i = 0; i < turma.length; i++){
	console.log(turma[i].nome);
};

//length = comprimento do vetor (tamanho)

//for each
console.log("--------------------------------");
for (var n in turma){
	console.log (turma[n].nome);
}



console.log("--------------------------------");
//FUNÇÕES

function dobraNumero (num){
	var dobro = num *2;
	return dobro;
}

var ano = 2019;
var dobroAno = dobraNumero(ano);
console.log(dobroAno);


// ###########################################
// ############### INTERAÇÃO #################
// ###########################################

function cumprimentar(){
	//Pegando o valor digitado na caixa de texto
	var nome = document.getElementById("txtNome").value;

	//Limpando a caixa de texto
	document.getElementById("txtNome").value = "";

	alert ("Olá, " + nome);
}

//cumprimentar();

//var nome2 = "";
//function adicionar(){
	//var nome = document.getElementById("txtNome").value;
	//nome2 = nome +" "+ nome2;
	//document.getElementById("box").innerHTML = nome2;
//}

function adicionar(){
	var novo = document.getElementById("txtNome").value;
	var antigo = document.getElementById("box").innerHTML;
	document.getElementById("box").innerHTML = antigo + "<br>" + novo;
}

// entrar no w3schools/ js references / 

//Array, String e Date
//no Date nao é necessario usar os métodos que possuam UTC
// array.js  string.js   date.js