// String Properties
<script>
//constructor
var str = "Hello World!";
document.getElementById("demo").innerHTML = str.constructor;

//length
function myFunction() {
  var str = "Hello World!";
  var n = str.length;
  document.getElementById("demo").innerHTML = n;
}

//prototype
function employee(name, jobtitle, born) {
  this.name = name;
  this.jobtitle = jobtitle;
  this.born = born;
}
employee.prototype.salary = 2000;

var fred = new employee("Fred Flintstone", "Caveman", 1970);
document.getElementById("demo").innerHTML = fred.salary;

//charAt()
function myFunction() {
  var str = "HELLO WORLD";
  var res = str.charAt(0)
  document.getElementById("demo").innerHTML = res;
}

//charCodeAt()
function myFunction() {
  var str = "HELLO WORLD";
  var n = str.charCodeAt(0);
  document.getElementById("demo").innerHTML = n;
}
//concat()
function myFunction() {
  var str1 = "Hello ";
  var str2 = "world!";
  var res = str1.concat(str2);
  document.getElementById("demo").innerHTML = res;
}

//endsWith()
function myFunction() {
  var str = "Hello world, welcome to the universe.";
  var n = str.endsWith("universe.");
  document.getElementById("demo").innerHTML = n;
}

//fromCharCode()
function myFunction() {
  var res = String.fromCharCode(65);
  document.getElementById("demo").innerHTML = res;
}

//fromCharCode()
function myFunction() {
  var res = String.fromCharCode(65);
  document.getElementById("demo").innerHTML = res;
}

//includes()
function myFunction() {
  var str = "Hello world, welcome to the universe.";
  var n = str.includes("world");
  document.getElementById("demo").innerHTML = n;
}

//indexOf()
function myFunction() {
  var str = "Hello world, welcome to the universe.";
  var n = str.indexOf("welcome");
  document.getElementById("demo").innerHTML = n;
}

//lastIndexOf()
function myFunction() {
  var str = "Hello planet earth, you are a great planet.";
  var n = str.lastIndexOf("planet");
  document.getElementById("demo").innerHTML = n;
}

//localeCompare()
function myFunction() {
  var str1 = "ab";
  var str2 = "cd";
  var n = str1.localeCompare(str2);
  document.getElementById("demo").innerHTML = n;
}

//match()
function myFunction() {
  var str = "The rain in SPAIN stays mainly in the plain"; 
  var res = str.match(/ain/g);
  document.getElementById("demo").innerHTML = res;
}

//repeat()
function myFunction() {
  var str = "Hello world!";
  document.getElementById("demo").innerHTML = str.repeat(2);
}

//replace()
function myFunction() {
  var str = document.getElementById("demo").innerHTML; 
  var res = str.replace("Microsoft", "W3Schools");
  document.getElementById("demo").innerHTML = res;
}

//search()
function myFunction() {
  var str = "Visit W3Schools!"; 
  var n = str.search("W3Schools");
  document.getElementById("demo").innerHTML = n;
}

//slice()
function myFunction() {
  var str = "Hello world!"; 
  var res = str.slice(0, 5);
  document.getElementById("demo").innerHTML = res;
}

//split()
function myFunction() {
  var str = "How are you doing today?";
  var res = str.split(" ");
  document.getElementById("demo").innerHTML = res;
}

//startsWith()
function myFunction() {
  var str = "Hello world, welcome to the universe.";
  var n = str.startsWith("Hello");
  document.getElementById("demo").innerHTML = n;
}

//substr()
function myFunction() {
  var str = "Hello world!";
  var res = str.substr(1, 4);
  document.getElementById("demo").innerHTML = res;
}

//substring()
function myFunction() {
  var str = "Hello world!";
  var res = str.substring(1, 4);
  document.getElementById("demo").innerHTML = res;
}

//toLocaleLowerCase()
function myFunction() {
  var str = "Hello World!";
  var res = str.toLocaleLowerCase();
  document.getElementById("demo").innerHTML = res;
}

//toLocaleUpperCase()
function myFunction() {
  var str = "Hello World!";
  var res = str.toLocaleUpperCase();
  document.getElementById("demo").innerHTML = res;
}

//toLowerCase()
function myFunction() {
  var str = "Hello World!";
  var res = str.toLowerCase();
  document.getElementById("demo").innerHTML = res;
}

//toString()
function myFunction() {
  var str = "Hello World!";
  var res = str.toString();
  document.getElementById("demo").innerHTML = res;
}

//toUpperCase()
function myFunction() {
  var str = "Hello World!";
  var res = str.toUpperCase();
  document.getElementById("demo").innerHTML = res;
}

//trim()
function myFunction() {
  var str = "     Hello World!     ";
  alert(str.trim());
}

//valueOf()
function myFunction() {
  var str = "Hello World!";
  var res = str.valueOf();
  document.getElementById("demo").innerHTML = res;
}
<\script>