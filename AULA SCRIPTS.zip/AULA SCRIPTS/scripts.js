//scripts.js
// variaveis (fracamente tipado)
//int, float, boolean, string, char, object, function
var a = 10;
var b = 20;
var c = a + b; // operação matemática

var nome = "Ana";
var sobrenome = "Mendes";
var nomeCompleto = nome +" "+ sobrenome; // Concatenação

console.log(nomeCompleto);

//operadores lógicos 
//&& (E), || (OU), ! (NOT)

//operadores condicionaris
//==, >, >=, <, <=, !=

//estruturas condicionais
var idade = 15

	if (idade >= 18) {
	console.log("Maior de idade");
}
	else if (idade <11) {
	console.log("Criança");
}
 	else{
	console.log('Menor de idade');
}

var civil = "C";
switch(civil){
	case "C":
		console.log("Casado");
		break;
	case "U":
		console.log("União estável");
		break;
	default:
		console.log("Solteiro");
		break;
}

//estruturas de repetição
var n = 1;
console.log("WHILE");
while (n <= 10){
	console.log( n );
	n++;
}

console.log("FOR");
for (var i =1; i<=10; i++){
	console.log(i);
}

//Vetores, Matrizes e Objetos
var cidades = new Array("Ituiutaba", "Capinópolis");
cidades[2] = "Santa Vitória";
cidades[cidades.length]= "Gurinhatã";
cidades[cidades.length]= "Canápolis";

console.log(cidades);

//Exibir todas as cidades em um FOR
for(var i=0; i< cidades.length; i++){
	console.log(cidades[i]);
}
console.log("--------------------------------");

//{} DEFINE OBJETO

var ficha = {
	//campo:valor,
	nome:"Bruno",
	idade:29,
	doador:true,
	altura:1.78
};

console.log(ficha);//mostra tudo
console.log(ficha["nome"]);//nome sintaxe de vetor
console.log(ficha.nome);//nome sintaxe de objeto

//for each(para cada), nao se prende a numeros e sim a indivíduos
console.log("FOR EACH");
for(var campo in ficha){
	console.log(campo + ": "+ ficha[campo]);
}

console.log("--------------------------------");

var pizza={
	sabor: "4 queijos",
	ingredientes: ["Mussarela", "Chedar", "Parmesão", "Catupiry"],
	tamanhos:{
		p: 19.90,
		m: 29.90,
		g: 39.90
	}

};

console.log( pizza.tamanhos.m );