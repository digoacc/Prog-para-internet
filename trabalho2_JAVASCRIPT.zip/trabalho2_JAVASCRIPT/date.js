<script>
// Date Object Properties
//constructor
var d = new Date();
document.getElementById("demo").innerHTML = d.constructor;

// prototype
function myFunction() {
  var d = new Date();
  d.myMet();
  document.getElementById("demo").innerHTML = d.myProp;
}


// Date Object Methods
// getDate()
function myFunction() {
  var d = new Date();
  var n = d.getDate();
  document.getElementById("demo").innerHTML = n;
}

// getDay()
function myFunction() {
  var d = new Date();
  var n = d.getDay()
  document.getElementById("demo").innerHTML = n;
}

// getFullYear()
function myFunction() {
  var d = new Date();
  var n = d.getFullYear();
  document.getElementById("demo").innerHTML = n;
}

// getHours()
function myFunction() {
  var d = new Date();
  var n = d.getHours();
  document.getElementById("demo").innerHTML = n;
}

// getMilliseconds()
function myFunction() {
  var d = new Date();
  var n = d.getMilliseconds();
  document.getElementById("demo").innerHTML = n;
}

// getMinutes()
function myFunction() {
  var d = new Date();
  var n = d.getMinutes();
  document.getElementById("demo").innerHTML = n;
}

// getMonth()
function myFunction() {
  var d = new Date();
  var n = d.getMonth();
  document.getElementById("demo").innerHTML = n;
}

// getSeconds()
function myFunction() {
  var d = new Date();
  var n = d.getSeconds();
  document.getElementById("demo").innerHTML = n;
}

// getTime()
function myFunction() {
  var d = new Date();
  var n = d.getTime();
  document.getElementById("demo").innerHTML = n;
}

// getTimezoneOffset()
function myFunction() {
  var d = new Date();
  var n = d.getTimezoneOffset();
  document.getElementById("demo").innerHTML = n;
}

// getUTCDate()
function myFunction() {
  var d = new Date();
  var n = d.getUTCDate();
  document.getElementById("demo").innerHTML = n;
}

// getUTCDay()
function myFunction() {
  var d = new Date();
  var n = d.getUTCDay();
  document.getElementById("demo").innerHTML = n;
}

// getUTCFullYear()
function myFunction() {
  var d = new Date();
  var n = d.getUTCFullYear();
  document.getElementById("demo").innerHTML = n;
}

// getUTCHours()
function myFunction() {
  var d = new Date();
  var n = d.getUTCHours();
  document.getElementById("demo").innerHTML = n;
}

// getUTCMilliseconds()
function myFunction() {
  var d = new Date();
  var n = d.getUTCMilliseconds();
  document.getElementById("demo").innerHTML = n;
}

// getUTCMinutes()
function myFunction() {
  var d = new Date();
  var n = d.getUTCMinutes();
  document.getElementById("demo").innerHTML = n;
}

// getUTCMonth()
function myFunction() {
  var d = new Date();
  var n = d.getUTCMonth();
  document.getElementById("demo").innerHTML = n;
}

// getUTCSeconds()
function myFunction() {
  var d = new Date();
  var n = d.getUTCSeconds();
  document.getElementById("demo").innerHTML = n;
}

// now()
function myFunction() {
  var n = Date.now();
  document.getElementById("demo").innerHTML = n;
}

// parse()
function myFunction() {
  var d = Date.parse("March 21, 2012");
  document.getElementById("demo").innerHTML = d;
}

// prototype
Date.prototype.myMet = function() {
  if (this.getMonth() == 0){this.myProp = "January"};
  if (this.getMonth() == 1){this.myProp = "February"};
  if (this.getMonth() == 2){this.myProp = "March"};
  if (this.getMonth() == 3){this.myProp = "April"};
  if (this.getMonth() == 4){this.myProp = "May"};
  if (this.getMonth() == 5){this.myProp = "June"};
  if (this.getMonth() == 6){this.myProp = "July"};
  if (this.getMonth() == 7){this.myProp = "August"};
  if (this.getMonth() == 8){this.myProp = "September"};
  if (this.getMonth() == 9){this.myProp = "October"};
  if (this.getMonth() == 10){this.myProp = "November"};
  if (this.getMonth() == 11){this.myProp = "December"};
};

function myFunction() {
  var d = new Date();
  d.myMet();
  document.getElementById("demo").innerHTML = d.myProp;
}

// setDate()
function myFunction() {
  var d = new Date();
  d.setDate(15);
  document.getElementById("demo").innerHTML = d;
}

// setFullYear()
function myFunction() {
  var d = new Date();
  d.setFullYear(2020);
  document.getElementById("demo").innerHTML = d;
}

// setHours()
function myFunction() {
  var d = new Date();
  d.setHours(15);
  document.getElementById("demo").innerHTML = d;
}

// setMilliseconds()
function myFunction() {
  var d = new Date();
  d.setMilliseconds(192);
  var n = d.getMilliseconds();
  document.getElementById("demo").innerHTML = n;
}

// setMinutes()
function myFunction() {
  var d = new Date();
  d.setMinutes(17);
  document.getElementById("demo").innerHTML = d;
}

// setMonth()
function myFunction() {
  var d = new Date();
  d.setMonth(4);
  document.getElementById("demo").innerHTML = d;
}

// setSeconds()
function myFunction() {
  var d = new Date();
  d.setSeconds(35);
  document.getElementById("demo").innerHTML = d;
}

// setTime()
function myFunction() {
  var d = new Date();
  d.setTime(1332403882588);
  document.getElementById("demo").innerHTML = d;
}

// setUTCDate()
function myFunction() {
  var d = new Date();
  d.setUTCDate(15);
  document.getElementById("demo").innerHTML = d;
}

// setUTCFullYear()
function myFunction() {
  var d = new Date();
  d.setUTCFullYear(2020);
  document.getElementById("demo").innerHTML = d;
}

// setUTCHours()
function myFunction() {
  var d = new Date();
  d.setUTCHours(15);
  document.getElementById("demo").innerHTML = d;
}

// setUTCMilliseconds()
function myFunction() {
  var d = new Date();
  d.setUTCMilliseconds(192);
  var n = d.getUTCMilliseconds();
  document.getElementById("demo").innerHTML = n;
}

// setUTCMinutes()
function myFunction() {
  var d = new Date();
  d.setUTCMinutes(17);
  document.getElementById("demo").innerHTML = d;
}

// setUTCMonth()
function myFunction() {
  var d = new Date();
  d.setUTCMonth(4);
  document.getElementById("demo").innerHTML = d;
}

// setUTCSeconds()
function myFunction() {
  var d = new Date();
  d.setUTCSeconds(35);
  document.getElementById("demo").innerHTML = d;
}

// toDateString()
function myFunction() {
  var d = new Date();
  var n = d.toDateString();
  document.getElementById("demo").innerHTML = n;
}

// toISOString()
function myFunction() {
  var d = new Date();
  var n = d.toISOString();
  document.getElementById("demo").innerHTML = n;
}

// toJSON()
function myFunction() {
  var d = new Date();
  var n = d.toJSON();
  document.getElementById("demo").innerHTML = n;
}

// toLocaleDateString()
function myFunction() {
  var d = new Date();
  var n = d.toLocaleDateString();
  document.getElementById("demo").innerHTML = n;
}

// toLocaleTimeString()
function myFunction() {
  var d = new Date();
  var n = d.toLocaleTimeString();
  document.getElementById("demo").innerHTML = n;
}

// toLocaleString()
function myFunction() {
  var d = new Date();
  var n = d.toLocaleString();
  document.getElementById("demo").innerHTML = n;
}

// toString()
function myFunction() {
  var d = new Date();
  var n = d.toString();
  document.getElementById("demo").innerHTML = n;
}

// toTimeString()
function myFunction() {
  var d = new Date();
  var n = d.toTimeString();
  document.getElementById("demo").innerHTML = n;
}

// toUTCString()
function myFunction() {
  var d = new Date();
  var n = d.toUTCString();
  document.getElementById("demo").innerHTML = n;
}

// UTC()
function myFunction() {
  var d = Date.UTC(2012, 02, 30);
  document.getElementById("demo").innerHTML = d;
}

// valueOf()
function myFunction() {
  var d = new Date();
  var n = d.valueOf();
  document.getElementById("demo").innerHTML = n;
}

<\script> 